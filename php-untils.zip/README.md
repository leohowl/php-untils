# install
composer: 
```bash
composer require leohowl/utils
```